#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	/*FILE *stdin;*/
	
	system("wolframscript -file H.w");
	
	return 0;
}

